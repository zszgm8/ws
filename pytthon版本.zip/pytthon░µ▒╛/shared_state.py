# shared_state.py
# -*- coding: utf-8 -*-

import asyncio
import json
import os
import sys
import time
import datetime
from collections import deque
import concurrent.futures
from typing import Dict, Any

# 尝试导入 psutil 用于系统监控
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    _original_print_fallback = print
    _original_print_fallback("[!] Warning: 'psutil' library not found. System status monitoring will be disabled. Run 'pip3 install psutil' to enable it.")

# ================ 全局配置与变量 ================

# --- 动态设置配置文件路径 ---
# 获取当前脚本 (shared_state.py) 所在的目录的绝对路径
_current_dir = os.path.dirname(os.path.abspath(__file__))
# 将配置文件路径设置为与脚本相同的目录，名为 ws_config.json
CONFIG_FILE = os.path.join(_current_dir, 'ws_config.json')
# --- 路径设置结束 ---


CONFIG: Dict[str, Any] = {}
SETTINGS: Dict[str, Any] = {}
ACTIVE_CONNS: Dict[str, Dict[str, Any]] = {}
DEVICE_USAGE: Dict[str, int] = {}
LOG_BUFFER = deque(maxlen=200)
START_TIME = time.time()
GLOBAL_BYTES_SENT = 0
GLOBAL_BYTES_RECEIVED = 0
# 确保在多线程环境中安全地执行阻塞操作
EXECUTOR = concurrent.futures.ThreadPoolExecutor(max_workers=os.cpu_count() or 4)

# --- 扩展print函数以捕获日志 ---
_original_print = print
def print(*args, **kwargs):
    """自定义print函数，将输出同时添加到日志缓冲区。"""
    _original_print(*args, **kwargs)
    message = " ".join(map(str, args))
    LOG_BUFFER.append(f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {message}")

# ------------------ 配置管理 ------------------
def save_config_sync(new_config: Dict[str, Any]):
    """同步保存配置到文件。"""
    global CONFIG, SETTINGS
    CONFIG = new_config
    SETTINGS = CONFIG.get('settings', {})
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(new_config, f, indent=2, ensure_ascii=False)
        # 确保文件权限，以便非root用户也能读写（如果需要）
        os.chmod(CONFIG_FILE, 0o666)
    except Exception as e:
        print(f"[!] Failed to save ws_config.json: {e}")

async def save_config_async(new_config: Dict[str, Any]):
    """异步保存配置。"""
    loop = asyncio.get_running_loop()
    await loop.run_in_executor(EXECUTOR, save_config_sync, new_config)

def load_config():
    """从文件加载配置，如果文件不存在则创建默认配置。"""
    global CONFIG, SETTINGS
    default_settings = {
        "http_port": 80, "tls_port": 443, "status_port": 9090,
        "default_target_host": "127.0.0.1", "default_target_port": 22,
        "buffer_size": 8192, "timeout": 300,
        "cert_file": "/etc/stunnel/certs/stunnel.pem", "key_file": "/etc/stunnel/certs/stunnel.key",
        "ua_keyword_ws": "26.4.0", "ua_keyword_probe": "1.0",
        "allow_simultaneous_connections": False,
        "default_expiry_days": 30, "default_limit_gb": 100,
        "ip_whitelist": [], "ip_blacklist": [],
        "enable_ip_whitelist": False, "enable_ip_blacklist": False,
        "enable_device_id_auth": True
    }
    if not os.path.exists(CONFIG_FILE):
        print(f"[*] Config file not found at '{CONFIG_FILE}', creating with default structure.")
        CONFIG = {"settings": default_settings, "accounts": {"admin": "admin"}, "device_ids": {}}
        save_config_sync(CONFIG)
    else:
        try:
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                CONFIG = json.load(f)
            settings = CONFIG.setdefault('settings', {})
            for key, value in default_settings.items():
                settings.setdefault(key, value)
            CONFIG.setdefault('accounts', {"admin": "admin"})
            CONFIG.setdefault('device_ids', {})
        except (json.JSONDecodeError, TypeError) as e:
            print(f"[!] FATAL: Could not decode {CONFIG_FILE}: {e}. Please check its format.")
            sys.exit(1)
            
    SETTINGS = CONFIG.get('settings', {})

def load_device_usage():
    """从配置中加载设备流量使用情况。"""
    global DEVICE_USAGE
    DEVICE_USAGE = {did: info.get('used_bytes', 0) for did, info in CONFIG.get('device_ids', {}).items()}

async def save_usage_periodically():
    """每隔5秒周期性地将内存中的流量使用情况保存到配置中。"""
    while True:
        await asyncio.sleep(5)
        is_dirty = False
        # 创建副本以避免在迭代时发生大小变化
        current_usage = dict(DEVICE_USAGE)
        for device_id, used_bytes in current_usage.items():
            if device_id in CONFIG.get('device_ids', {}) and CONFIG['device_ids'][device_id].get('used_bytes') != used_bytes:
                CONFIG['device_ids'][device_id]['used_bytes'] = used_bytes
                is_dirty = True
        
        if is_dirty:
            await save_config_async(CONFIG)

# 初始化加载
load_config()
load_device_usage()
