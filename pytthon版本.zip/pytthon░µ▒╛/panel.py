# panel.py
# -*- coding: utf-8 -*-

import asyncio
import base64
import json
import re
import shutil
import subprocess
import time
import datetime
import os
import sys
from typing import Tuple, List, Dict, Any

# 从共享模块导入所有需要的变量和函数
from shared_state import (
    ACTIVE_CONNS, DEVICE_USAGE, LOG_BUFFER, CONFIG, SETTINGS, EXECUTOR, START_TIME,
    GLOBAL_BYTES_SENT, GLOBAL_BYTES_RECEIVED, PSUTIL_AVAILABLE,
    save_config_async, print
)

# 仅在此文件中需要 psutil
if PSUTIL_AVAILABLE:
    import psutil

# ------------------ SSH 用户管理模块 ------------------
def run_command(command: list) -> Tuple[bool, str]:
    """执行系统命令并返回结果。"""
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        return True, result.stdout.strip()
    except FileNotFoundError:
        return False, f"命令未找到: {command[0]}"
    except subprocess.CalledProcessError as e:
        return False, f"命令执行失败: {command}\n错误: {e.stderr.strip()}"

def manage_ssh_user(username: str, password: str = None, action: str = 'create') -> Tuple[bool, str]:
    """管理SSH用户（创建/删除）。"""
    if os.geteuid() != 0: return False, "此操作需要 root 权限。"
    if not re.match(r'^[a-z_][a-z0-9_-]{0,30}$', username): return False, "无效的用户名。请使用小写字母、数字、下划线或连字符。"
    sshd_config_path = '/etc/ssh/sshd_config'
    start_marker = f'# WSSUSER_BLOCK_START_{username}'
    end_marker = f'# WSSUSER_BLOCK_END_{username}'
    if action == 'delete':
        try:
            with open(sshd_config_path, 'r') as f: lines = f.readlines()
            new_lines = []
            in_block = False
            if any(start_marker in line for line in lines):
                for line in lines:
                    if start_marker in line: in_block = True
                    if not in_block: new_lines.append(line)
                    if end_marker in line: in_block = False
                with open(sshd_config_path, 'w') as f: f.writelines(new_lines)
        except Exception as e: return False, f"清理 sshd_config 失败: {e}"
        if run_command(['id', username])[0]:
            del_success, msg = run_command(['userdel', '-r', username])
            if not del_success: return False, f"删除用户失败: {msg}"
        sshd_restart_success, msg = run_command(['systemctl', 'restart', 'sshd'])
        if not sshd_restart_success: return False, f"SSHD 重启失败: {msg}"
        return True, f"用户 {username} 及相关配置已成功删除。"
    if action == 'create':
        if not password: return False, "创建用户时必须提供密码。"
        if not run_command(['id', username])[0]:
            add_success, msg = run_command(['useradd', '-m', '-s', '/bin/bash', username])
            if not add_success: return False, f"创建用户失败: {msg}"
        try:
            subprocess.run(['chpasswd'], input=f'{username}:{password}\n'.encode(), capture_output=True, check=True)
        except subprocess.CalledProcessError as e: return False, f"设置密码失败: {e.stderr.decode().strip()}"
        try:
            shutil.copy2(sshd_config_path, f'{sshd_config_path}.bak.wss_{int(time.time())}')
            with open(sshd_config_path, 'r') as f: lines = f.readlines()
            new_lines = []
            in_block = False
            for line in lines:
                if start_marker in line: in_block = True
                if not in_block: new_lines.append(line)
                if end_marker in line: in_block = False
            new_block = f"\n{start_marker}\nMatch User {username} Address 127.0.0.1,::1\n    PasswordAuthentication yes\n    PermitTTY yes\n    AllowTcpForwarding yes\nMatch User {username} Address *,!127.0.0.1,!::1\n    PasswordAuthentication no\n    PermitTTY no\n    AllowTcpForwarding no\n{end_marker}\n"
            with open(sshd_config_path, 'w') as f: f.writelines(new_lines); f.write(new_block)
        except Exception as e: return False, f"修改 sshd_config 失败: {e}"
        sshd_restart_success, msg = run_command(['systemctl', 'restart', 'sshd'])
        if not sshd_restart_success: return False, f"SSHD 重启失败: {msg}"
        return True, f"SSH 用户 '{username}' 已成功创建/更新。"
    return False, "未知操作。"

# ------------------ 面板辅助函数 ------------------
def format_bytes(b):
    """格式化字节大小为可读字符串。"""
    if b is None or b < 0: return "0 B"
    p, n, l = 1024, 0, {0: 'B', 1: 'KB', 2: 'MB', 3: 'GB', 4: 'TB'}
    while b >= p and n < 4:
        b /= p
        n += 1
    return f"{b:.2f} {l[n]}"

def parse_request_path(t: str) -> Tuple[str, str]:
    """解析HTTP请求行，获取方法和路径。"""
    parts = t.splitlines()[0].split() if t else []
    return (parts[0].upper(), parts[1]) if len(parts) >= 2 else ("GET", "/")

async def send_unauthorized(w: asyncio.StreamWriter):
    """发送401 Unauthorized响应。"""
    resp = b"HTTP/1.1 401 Unauthorized\r\nWWW-Authenticate: Basic realm=\"Admin\"\r\n\r\n"
    w.write(resp)
    await w.drain()
    try:
        if not w.is_closing():
            w.close()
            await w.wait_closed()
    except:
        pass

def extract_header_value(text: str, names: list) -> str:
    """从HTTP头文本中提取指定头的值。"""
    for name in names:
        m = re.search(fr'(?mi)^{re.escape(name)}:\s*(.+)$', text)
        if m:
            return m.group(1).strip()
    return ''

def check_basic_auth(t: str) -> Tuple[bool, str]:
    """检查HTTP Basic认证。"""
    auth_header = extract_header_value(t, ['Authorization'])
    if auth_header and auth_header.lower().startswith('basic '):
        try:
            decoded = base64.b64decode(auth_header[6:]).decode()
            u, p = decoded.split(":", 1)
            if CONFIG.get("accounts", {}).get(u) == p:
                return True, u
        except Exception:
            pass
    return False, ""

def get_server_status_sync():
    """同步获取服务器状态。"""
    if not PSUTIL_AVAILABLE:
        return None
    uptime = time.time() - START_TIME
    mem = psutil.virtual_memory()
    return {
        "uptime": str(datetime.timedelta(seconds=int(uptime))),
        "cpu_percent": psutil.cpu_percent(interval=None),
        "cpu_cores": psutil.cpu_count(logical=True),
        "mem_total": mem.total,
        "mem_used": mem.used,
        "mem_percent": mem.percent,
        "bytes_sent": GLOBAL_BYTES_SENT,
        "bytes_received": GLOBAL_BYTES_RECEIVED
    }

async def get_server_status_async():
    """异步获取服务器状态。"""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(EXECUTOR, get_server_status_sync)

def get_connections_data() -> List[Dict]:
    """获取并格式化当前所有连接的数据，用于API。"""
    status_order = {'活跃': 0, '握手': 1}
    conns_list = sorted(list(ACTIVE_CONNS.values()), key=lambda x: (status_order.get(x['status'], 2), x.get('first_connection', 0)))
    resp, now = [], time.time()
    for i in conns_list:
        did = i.get('device_id', "握手中...")
        meta = CONFIG.get('device_ids', {}).get(did, {})
        limit_gb = meta.get('limit_gb', 0)
        rem_str = "无限制"
        if limit_gb > 0 and did != "握手中...":
            rem_str = format_bytes(limit_gb * 1024**3 - DEVICE_USAGE.get(did, 0))
        
        speed_val = 0
        if i.get('status') == '活跃':
            time_delta = now - i.get('last_speed_update_time', now)
            if time_delta >= 2:
                current_total_bytes = i['bytes_sent'] + i['bytes_received']
                bytes_delta = current_total_bytes - i.get('last_total_bytes', 0)
                speed_val = bytes_delta / time_delta if time_delta > 0 else 0
                i['current_speed'], i['last_speed_update_time'], i['last_total_bytes'] = speed_val, now, current_total_bytes
            else:
                speed_val = i.get('current_speed', 0)

        resp.append({
            "device_id": did, "status": i['status'], "sent_str": format_bytes(i['bytes_sent']),
            "rcvd_str": format_bytes(i['bytes_received']), "remaining_str": rem_str,
            "speed_str": f"{format_bytes(speed_val)}/s", "expiry": meta.get('expiry', '?'),
            "ip": i['ip'], "first_conn": time.strftime('%H:%M:%S', time.localtime(i.get('first_connection', 0))),
            "last_active": time.strftime('%H:%M:%S', time.localtime(i.get('last_active', 0))),
            "conn_key": i['conn_key']
        })
    return resp

# ------------------ 主管理界面逻辑 ------------------
async def admin_interface(reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
    """处理对管理面板的HTTP请求。"""
    try:
        req_text_bytes = await asyncio.wait_for(reader.read(65536), timeout=10)
        req_text = req_text_bytes.decode(errors='ignore')
        method,path=parse_request_path(req_text)
        auth_ok,user=check_basic_auth(req_text)
        if not auth_ok: await send_unauthorized(writer); return

        if path.startswith("/api/"):
            resp: Dict[str, Any] = {'status':'error','message':'Unknown API'}; code="404 Not Found"
            body_parts = req_text.split("\r\n\r\n", 1)
            body = body_parts[1] if len(body_parts) > 1 else ""
            data: Dict[str, Any] = {}
            if body:
                try: data = json.loads(body)
                except json.JSONDecodeError: 
                    resp={'status':'error','message':'Invalid JSON body'}; code="400 Bad Request"
                    resp_body=json.dumps(resp).encode()
                    writer.write(f"HTTP/1.1 {code}\r\nContent-Type: application/json\r\nContent-Length: {len(resp_body)}\r\n\r\n".encode()+resp_body); await writer.drain(); return
            
            if path=="/api/kick":
                kicked = False
                conn_key_to_kick = data.get("conn_key")
                if not conn_key_to_kick:
                    resp = {'status': 'error', 'message': '缺少 conn_key'}
                    code = "400 Bad Request"
                else:
                    conn_to_kick = ACTIVE_CONNS.get(conn_key_to_kick)
                    if conn_to_kick:
                        try:
                            w = conn_to_kick['writer']
                            if not w.is_closing(): w.close(); await w.wait_closed()
                            kicked = True
                        except Exception as e:
                            print(f"Error while kicking conn {conn_key_to_kick}: {e}")
                    
                    did_display = conn_to_kick.get('device_id', 'N/A') if conn_to_kick else 'N/A'
                    resp = {'status': 'ok' if kicked else 'error', 'message': f'连接 (ID: {did_display}) {"已踢掉" if kicked else "未找到"}'}
                    code = "200 OK"
            elif path in ["/api/ssh/create", "/api/ssh/delete"]:
                action = path.split("/")[-1]
                username, password = data.get("username"), data.get("password")
                loop = asyncio.get_running_loop()
                success, message = await loop.run_in_executor(EXECUTOR, manage_ssh_user, username, password, action)
                resp = {'status': 'ok' if success else 'error', 'message': message}; code = "200 OK"
            elif path == "/api/settings/toggle_device_auth":
                try:
                    enable = bool(data.get("enable"))
                    current_config = CONFIG.copy()
                    current_config['settings']['enable_device_id_auth'] = enable
                    await save_config_async(current_config)
                    status_text = "开启" if enable else "关闭"
                    resp = {'status': 'ok', 'message': f'Device ID 验证已{status_text}'}
                    code = "200 OK"
                except Exception as e:
                    resp = {'status': 'error', 'message': f'操作失败: {e}'}
                    code = "500 Internal Server Error"
            elif path=="/api/clear":
                if data.get("conn_key") in ACTIVE_CONNS: ACTIVE_CONNS.pop(data.get("conn_key"), None)
                resp={'status':'ok'}; code="200 OK"
            elif path=="/api/device_usage": resp=DEVICE_USAGE; code="200 OK"
            elif path=="/api/connections": resp = get_connections_data(); code="200 OK"
            elif path=="/api/logs": resp=list(LOG_BUFFER); code="200 OK"
            elif path=="/api/server_status": resp = await get_server_status_async() or {}; code="200 OK"
            elif path=="/api/devices": resp = CONFIG['device_ids']; code="200 OK"
            elif path=="/api/settings": resp = CONFIG['settings']; code="200 OK"
            
            resp_body=json.dumps(resp).encode()
            writer.write(f"HTTP/1.1 {code}\r\nContent-Type: application/json\r\nContent-Length: {len(resp_body)}\r\n\r\n".encode()+resp_body); await writer.drain(); return
        
        if method=="POST":
            if path=="/logout": writer.write(b"HTTP/1.1 401 Unauthorized\r\n\r\n"); await writer.drain(); return
            resp={'status':'error','message':'无效请求'}; code="400 Bad Request"
            body_parts = req_text.split("\r\n\r\n", 1); body = body_parts[1] if len(body_parts) > 1 else ""; data = {}
            if body:
                try: data = json.loads(body)
                except json.JSONDecodeError: resp={'status':'error','message':'无效的JSON格式'}; code="400 Bad Request"
            
            if path=="/device/add":
                did,exp,lim=data.get("device_id"),data.get("expiry"),data.get("limit_gb",0)
                if did and exp:
                    if did not in CONFIG["device_ids"]: DEVICE_USAGE[did]=0
                    CONFIG["device_ids"][did]={"expiry":exp,"limit_gb":int(lim),"used_bytes":DEVICE_USAGE.get(did,0)}; await save_config_async(CONFIG); resp={'status':'ok','message':'保存成功'}
            elif path=="/device/delete":
                did=data.get("device_id")
                if did and did in CONFIG["device_ids"]:
                    CONFIG["device_ids"].pop(did); DEVICE_USAGE.pop(did,None); await save_config_async(CONFIG); resp={'status':'ok','message':'删除成功'}
            elif path=="/device/reset_traffic":
                did=data.get("device_id")
                if did and did in CONFIG["device_ids"]:
                    DEVICE_USAGE[did]=0; CONFIG["device_ids"][did]['used_bytes']=0; await save_config_async(CONFIG); resp={'status':'ok','message':'流量已重置'}
            elif path=="/account/update":
                ou,op,nu,np=data.get("old_user"),data.get("old_pass"),data.get("new_user"),data.get("new_pass")
                if CONFIG["accounts"].get(ou)==op:
                    CONFIG["accounts"].pop(ou,None); CONFIG["accounts"][nu]=np; await save_config_async(CONFIG); resp={'status':'ok','message':'修改成功'}
                else: resp={'status':'error','message':'原账号或密码错误'}
            elif path=="/settings/save":
                try:
                    new_cfg=CONFIG.copy(); new_s=new_cfg['settings']
                    new_s.update({k: (v.strip() if isinstance(v,str) else v) for k,v in data.items() if k not in ['ip_whitelist', 'ip_blacklist']})
                    for k in ['http_port','tls_port','status_port','default_target_port','buffer_size','timeout','default_expiry_days','default_limit_gb']: new_s[k]=int(new_s[k])
                    new_s['allow_simultaneous_connections']=bool(data.get("allow_simultaneous_connections")); new_s['enable_ip_whitelist']=bool(data.get("enable_ip_whitelist")); new_s['enable_ip_blacklist']=bool(data.get("enable_ip_blacklist"))
                    for k in ['ip_whitelist','ip_blacklist']: new_s[k]=[i.strip() for i in data.get(k,"").split(',') if i.strip()]
                    await save_config_async(new_cfg); resp={'status':'ok','message':'配置已保存, 正在重启...'}; code="200 OK"
                except Exception as e: resp={'status':'error','message':f'保存失败: {e}'}
                resp_body=json.dumps(resp).encode(); writer.write(f"HTTP/1.1 {code}\r\nContent-Type: application/json\r\nContent-Length: {len(resp_body)}\r\n\r\n".encode()+resp_body); await writer.drain()
                if resp['status']=='ok':
                    await asyncio.sleep(1); print("[*] Restarting server..."); os.execl(sys.executable,sys.executable,*sys.argv)
                return
            
            resp_body=json.dumps(resp).encode(); writer.write(f"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: {len(resp_body)}\r\n\r\n".encode()+resp_body); await writer.drain(); return
        
        active_count = sum(1 for i in ACTIVE_CONNS.values() if i['status'] == '活跃')
        s_status = await get_server_status_async()
        if s_status:
            mem_used_gb = s_status['mem_used'] / (1024**3); mem_total_gb = s_status['mem_total'] / (1024**3); mem_str = f"{mem_used_gb:.1f} / {mem_total_gb:.1f} GB ({s_status['mem_percent']:.1f}%)"
            cpu_str = f"{s_status['cpu_percent']:.1f}%"; uptime_str = s_status["uptime"]; cpu_cores_str = str(s_status.get('cpu_cores', 'N/A'))
        else: mem_str, cpu_str, uptime_str, cpu_cores_str = "N/A", "N/A", "N/A", "N/A"
        
        html_template = '''<!doctype html><html><head><meta charset="utf-8"><title>WSTunnel Admin</title><style>
        body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";background:#f4f7fb;margin:0;font-size:15px}
        .container{max-width:1400px;margin:0 auto;padding:0 18px}
        .card{background:white;border-radius:8px;padding:18px;margin-top:12px;box-shadow:0 4px 14px rgba(20,30,60,0.06)}
        table{width:100%;border-collapse:collapse;font-size:14px}th{white-space:nowrap}thead th{position:sticky;top:0;background:#fff;padding:10px 12px;text-align:left;border-bottom:2px solid #eef2f7;font-weight:700}th,td{padding:10px 12px;border-bottom:1px solid #f1f5f9;word-wrap:break-word;}tr:last-child td {border-bottom: none;}.table-container,.device-list-container{overflow:auto;border-radius:8px;border:1px solid #e6eef8;margin-top:8px}.table-container{max-height:calc(100vh - 400px)}.device-list-container{max-height:360px}.btn{border:0;padding:8px 12px;border-radius:6px;cursor:pointer;font-weight:700;color:white;transition:opacity .2s}.btn:hover{opacity:0.85}.btn.primary{background:#2563eb}.btn.secondary{background:#10b981}.btn.danger{background:#dc2626}.btn.info{background:#0ea5e9}.btn.warning{background:#f59e0b}.status-pill{display:inline-block;padding:6px 10px;border-radius:999px;font-weight:700;font-size:13px}.status-active{background:#e6ffed;color:#065f46}.status-down{background:#fff2f2;color:#991b1b}.status-handshake{background:#fffbeb;color:#b45309}.navbar{display:flex;gap:8px;align-items:center;padding:8px 0;flex-wrap:wrap;border-bottom: 1px solid #e2e8f0;}.navbar a{padding:8px 12px;border-radius:8px;text-decoration:none;font-weight:700;color:#0f172a;transition:background-color .2s, color .2s}.navbar a.active{background:#eef2ff; color:#2563eb;}.navbar a:not(.active):hover{background-color:#f8fafc;}.form-row{display:flex;gap:10px;align-items:center;margin-top:8px;flex-wrap:wrap}.form-row label{min-width:180px;font-weight:600}input[type="text"],input[type="password"],select{height:32px;font-size:14px;padding:4px 8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box}.status-bar{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;padding:12px 0}.status-card{background:#fff;border-radius:8px;padding:12px 16px;box-shadow:0 4px 12px rgba(20,30,60,0.05);border:1px solid #eef2f7;display:flex;flex-direction:column;gap:4px}.status-card span{font-size:14px;color:#64748b}.status-card strong{font-size:16px;color:#0f172a;font-weight:600}.status-card small{font-size:12px;color:#94a3b8}.settings-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:18px;margin-top:12px}.settings-group{border:1px solid #eef2f7;border-radius:8px;padding:12px 16px}.settings-group h3{margin-top:0;font-size:16px;border-bottom:1px solid #eef2f7;padding-bottom:10px;margin-bottom:16px}.settings-group .form-row{margin-top:12px}.settings-group .form-row label{min-width:140px;text-align:right;font-weight:normal;color:#334155}.settings-group .form-row input[type=text]{flex-grow:1}.settings-group .form-row.full-width{flex-direction:column;align-items:flex-start}.settings-group .form-row.full-width label{text-align:left;margin-bottom:5px;min-width:auto}.settings-group .form-row.full-width input{width:100%;box-sizing:border-box}
        .toggle-switch{position:relative;display:inline-block;width:50px;height:28px}
        .toggle-switch input{opacity:0;width:0;height:0}
        .slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#ccc;transition:.4s;border-radius:28px}
        .slider:before{position:absolute;content:"";height:20px;width:20px;left:4px;bottom:4px;background-color:white;transition:.4s;border-radius:50%}
        input:checked+.slider{background-color:#2563eb}
        input:checked+.slider:before{transform:translateX(22px)}
        </style></head><body><div class="container"><nav class="navbar"><a href="#/status">连接状态</a><a href="#/device">设备管理</a><a href="#/account">账号设置</a><a href="#/settings">系统设置</a><a href="#/logs">系统日志</a><a style="margin-left:auto;background:#ff6b6b;color:#fff;border-radius:6px;padding:8px 12px;text-decoration:none" href="#" onclick="logout()">退出</a></nav><div class="status-bar"><div class="status-card"><span>登录用户</span><strong id="current-user">__USER__</strong></div><div class="status-card"><span>活跃连接</span><strong id="active-connections">__ACTIVE_COUNT__</strong></div><div class="status-card"><span>总上传</span><strong id="global-sent">__GLOBAL_SENT__</strong></div><div class="status-card"><span>总下载</span><strong id="global-received">__GLOBAL_RECEIVED__</strong></div><div class="status-card"><span>运行时长</span><strong id="server-uptime">__UPTIME__</strong></div><div class="status-card"><span>CPU <small>(核心)</small></span><strong><span id="cpu-usage">__CPU__</span> (<span id="cpu-cores">__CPU_CORES__</span>)</strong></div><div class="status-card"><span>内存使用</span><strong id="mem-usage">__MEM__</strong></div></div><main id="content-area"></main></div>
        <script>
        const gid = id => document.getElementById(id); const contentArea = gid('content-area');
        let appState = { devices: {}, usage: {}, settings: null, connections: [], logs: [] };
        let activeIntervals = [];
        async function apiRequest(url, options = {}) {
            try {
                const response = await fetch(url, options);
                if (!response.ok) { throw new Error(`HTTP error! status: ${response.status}`); }
                return await response.json();
            } catch (error) {
                console.error(`API request to ${url} failed:`, error);
                if (options.method === 'POST') alert(`操作失败: ${error.message}`);
                return null;
            }
        }
        const get = (url) => apiRequest(url);
        const post = (url, data) => apiRequest(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
        function formatBytesJS(b, d = 2) { if (b <= 0) return "0 B"; const k = 1024, s = ["B", "KB", "MB", "GB", "TB"], i = Math.floor(Math.log(b) / Math.log(k)); return parseFloat((b / Math.pow(k, i)).toFixed(d)) + " " + s[i]; }
        function renderConnectionsTable() {
            const t = gid('connections-body'); if (!t) return; let h = '';
            if (appState.connections.length === 0) { h = '<tr><td colspan="11" style="text-align:center;">暂无连接</td></tr>'; } 
            else { const statusClasses = { '活跃': 'active', '断开': 'down', '握手': 'handshake' }; appState.connections.forEach(c => {
                let b = c.status === '活跃' ? `<button class="btn danger" onclick="kickUser('${c.conn_key}', '${c.device_id}')">踢掉</button>` : `<button class="btn info" onclick="clearConnection('${c.conn_key}')">清除</button>`;
                const statusClass = statusClasses[c.status] || 'down';
                h += `<tr><td>${c.device_id}</td><td><span class="status-pill status-${statusClass}">${c.status}</span></td><td>${c.sent_str}</td><td>${c.rcvd_str}</td><td>${c.speed_str}</td><td>${c.remaining_str}</td><td>${c.expiry}</td><td>${c.ip}</td><td>${c.first_conn}</td><td>${c.last_active}</td><td>${b}</td></tr>`;
            }); }
            t.innerHTML = h; filterTable();
        }
        function renderStatusPage() {
            contentArea.innerHTML = `<div class="card"><h2>连接状态</h2><div class="form-row"><input id="search_input" type="text" placeholder="模糊搜索..." onkeyup="filterTable()"></div>
        <div class="table-container"><table id="connections"><thead><tr><th>客户端ID</th><th>状态</th><th>上传</th><th>下载</th><th>当前速率</th><th>剩余流量</th><th>有效期</th><th>IP地址</th><th>首次连接</th><th>上次活动</th><th>操作</th></tr></thead>
        <tbody id="connections-body"></tbody></table></div></div>`;
            renderConnectionsTable();
        }
        function renderDevicePage() {
            if (!appState.settings) { contentArea.innerHTML = `<div class="card">正在加载初始数据...</div>`; return; }
            const authEnabled = appState.settings.enable_device_id_auth;
            let optionsHtml = '<option value="">--填充--</option>';
            Object.entries(appState.devices).forEach(([did, info]) => { optionsHtml += `<option value="${did}|${info.expiry}|${info.limit_gb}">${did}</option>`; });
            let tableRowsHtml = '';
            Object.entries(appState.devices).forEach(([did, info]) => {
                const limit = info.limit_gb > 0 ? `${info.limit_gb} GB` : '无限';
                const used = appState.usage[did] || 0;
                tableRowsHtml += `<tr id="device-row-${did}"><td>${did}</td><td>${info.expiry}</td><td>${limit}</td><td class="used-traffic">${formatBytesJS(used)}</td></tr>`;
            });
            contentArea.innerHTML = `<div class="card">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <h2>设备管理</h2>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <label class="toggle-switch">
                            <input type="checkbox" id="device-auth-toggle" ${authEnabled ? 'checked' : ''} onchange="toggleDeviceAuth()">
                            <span class="slider"></span>
                        </label>
                        <span id="device-auth-status-text">${authEnabled ? "Device ID 验证: 开启" : "已关闭 (全部放行)"}</span>
                    </div>
                </div>
                <div class="form-row"><label>选择已有:</label><select id="existing_user" onchange="fillExisting()">${optionsHtml}</select></div>
                <div class="form-row"><label>ID:</label><input id="device_id" type="text"><label>有效期:</label><input id="expiry" type="text" placeholder="YYYY-MM-DD"><label>流量(GB):</label><input id="limit_gb" type="text" placeholder="0为无限"><button class="btn primary" onclick="addID()">保存</button><button class="btn danger" onclick="deleteID()">删除</button><button class="btn secondary" onclick="resetTraffic()">重置流量</button></div>
                <div class="form-row"><label>自动生成(天):</label><input id="auto_expiry" type="text" value="${appState.settings.default_expiry_days}"><label>自动生成(GB):</label><input id="auto_limit" type="text" value="${appState.settings.default_limit_gb}"><button class="btn info" onclick="autoFill()">填充日期和流量</button></div>
            </div>
            <div class="card"><h3>当前列表</h3><div class="device-list-container"><table id="device-list"><thead><tr><th>ID</th><th>有效期</th><th>流量限制</th><th>已用流量</th></tr></thead><tbody>${tableRowsHtml}</tbody></table></div></div>`;
        }
        function renderAccountPage() {
            contentArea.innerHTML = `<div class="card"><h2>面板账号设置</h2><div class="form-row"><label>原账号:</label><input id="old_user" type="text"><label>原密码:</label><input id="old_pass" type="password"></div><div class="form-row"><label>新账号:</label><input id="new_user" type="text"><label>新密码:</label><input id="new_pass" type="password"><button class="btn secondary" onclick="updateAccount()">保存</button></div></div><div class="card"><h2>创建SSH隧道用户 (仅限本机登录)</h2><p style="font-size:13px;color:#64748b;">此功能会创建或更新一个系统用户，并修改 <b>/etc/ssh/sshd_config</b> 文件，以仅允许该用户从 127.0.0.1 (本机) 通过密码登录。主要用于 WSS payload 转发。请确保脚本以 root 权限运行。</p><div class="form-row"><label>SSH 用户名:</label><input id="ssh_user" type="text"><label>SSH 密码:</label><input id="ssh_pass" type="password"></div><div class="form-row" style="margin-top: 15px; gap: 15px;"><button class="btn secondary" onclick="manageSshUser('create')">创建/更新用户</button><button class="btn danger" onclick="manageSshUser('delete')">删除用户</button></div></div>`;
        }
        function renderSettingsPage() {
            const s = appState.settings; if (!s) { contentArea.innerHTML = `<div class="card">正在加载初始数据...</div>`; return; }
            const ip_whitelist_text = s.ip_whitelist.join(','); const ip_blacklist_text = s.ip_blacklist.join(',');
            contentArea.innerHTML = `<div class="card"><h2>系统设置</h2><div class="settings-grid"><div class="settings-group"><h3>服务器与端口</h3><div class="form-row"><label>WS端口 (http):</label><input id="s_http_port" type="text" value="${s.http_port}"></div><div class="form-row"><label>WSS端口 (tls):</label><input id="s_tls_port" type="text" value="${s.tls_port}"></div><div class="form-row"><label>管理后台端口:</label><input id="s_status_port" type="text" value="${s.status_port}"></div><div class="form-row full-width"><label>证书文件路径 (cert_file):</label><input id="s_cert_file" type="text" value="${s.cert_file}"></div><div class="form-row full-width"><label>密钥文件路径 (key_file):</label><input id="s_key_file" type="text" value="${s.key_file}"></div></div><div class="settings-group"><h3>连接与行为</h3><div class="form-row"><label>WS握手UA:</label><input id="s_ua_keyword_ws" type="text" value="${s.ua_keyword_ws}"></div><div class="form-row"><label>探测握手UA:</label><input id="s_ua_keyword_probe" type="text" value="${s.ua_keyword_probe}"></div><div class="form-row"><label>默认目标地址:</label><input id="s_default_target_host" type="text" value="${s.default_target_host}"></div><div class="form-row"><label>默认目标端口:</label><input id="s_default_target_port" type="text" value="${s.default_target_port}"></div><div class="form-row"><label>缓冲区(Bytes):</label><input id="s_buffer_size" type="text" value="${s.buffer_size}"></div><div class="form-row"><label>连接超时(秒):</label><input id="s_timeout" type="text" value="${s.timeout}"></div><div class="form-row" style="justify-content:space-between;padding-left:140px"><label style="min-width:auto;text-align:left;">允许同ID多点登录:</label><input id="s_allow_simultaneous_connections" type="checkbox" ${s.allow_simultaneous_connections ? 'checked' : ''}></div></div><div class="settings-group"><h3>用户与安全</h3><div class="form-row"><label>新设备默认有效期(天):</label><input id="s_default_expiry_days" type="text" value="${s.default_expiry_days}"></div><div class="form-row"><label>新设备默认流量(GB):</label><input id="s_default_limit_gb" type="text" value="${s.default_limit_gb}"></div><hr style="border:none; border-top:1px solid #f1f5f9; margin: 16px 0;"><div class="form-row" style="justify-content:space-between;padding-left:140px"><label style="min-width:auto;text-align:left;">启用IP白名单:</label><input id="s_enable_ip_whitelist" type="checkbox" ${s.enable_ip_whitelist ? 'checked' : ''}></div><div class="form-row full-width"><label>IP白名单列表 (逗号分隔):</label><input id="s_ip_whitelist" type="text" value="${ip_whitelist_text}"></div><div class="form-row" style="justify-content:space-between;padding-left:140px"><label style="min-width:auto;text-align:left;">启用IP黑名单:</label><input id="s_enable_ip_blacklist" type="checkbox" ${s.enable_ip_blacklist ? 'checked' : ''}></div><div class="form-row full-width"><label>IP黑名单列表 (逗号分隔):</label><input id="s_ip_blacklist" type="text" value="${ip_blacklist_text}"></div></div></div><div class="form-row" style="margin-top: 20px;"><button class="btn warning" onclick="saveSettings()">保存并重启</button></div></div>`;
        }
        function renderLogsPage() {
            contentArea.innerHTML = `<div class="card"><h2>日志查看器(最新200条)</h2><div id="log-viewer" style="height:calc(100vh - 250px);overflow:auto;background:#282c34;color:#abb2bf;padding:10px;border-radius:8px;font-family:monospace;font-size:12px;white-space:pre-wrap;"></div></div>`;
            const v = gid('log-viewer'); if (!v) return; v.innerHTML = appState.logs.join('\\n'); v.scrollTop = v.scrollHeight;
        }
        async function updateDynamicData() {
            const [statusData, connsData, usageData, logsData] = await Promise.all([
                get('/api/server_status'), get("/api/connections"), get("/api/device_usage"), get("/api/logs")
            ]);
            if (statusData) {
                if(gid('cpu-usage')) gid('cpu-usage').textContent = (statusData.cpu_percent !== undefined) ? statusData.cpu_percent.toFixed(1) + '%' : 'N/A';
                if(gid('cpu-cores')) gid('cpu-cores').textContent = statusData.cpu_cores || 'N/A';
                if(gid('mem-usage') && statusData.mem_percent !== undefined) { const used_gb = statusData.mem_used / (1024**3); const total_gb = statusData.mem_total / (1024**3); gid('mem-usage').textContent = `${used_gb.toFixed(1)} / ${total_gb.toFixed(1)} GB (${statusData.mem_percent.toFixed(1)}%)`; } 
                if(gid('server-uptime')) gid('server-uptime').textContent = statusData.uptime || 'N/A'; 
                if(gid('global-sent')) gid('global-sent').textContent = formatBytesJS(statusData.bytes_sent || 0); 
                if(gid('global-received')) gid('global-received').textContent = formatBytesJS(statusData.bytes_received || 0); 
            }
            if (connsData) { appState.connections = connsData; if(gid('active-connections')) gid('active-connections').textContent = connsData.filter(c => c.status === '活跃').length; }
            if (usageData) { appState.usage = usageData; }
            if (logsData) { appState.logs = logsData; }
            const path = window.location.hash || '#/status';
            if(path === '#/status') renderConnectionsTable();
            if(path === '#/device') { Object.entries(appState.usage).forEach(([did, usage]) => { const cell = document.querySelector(`#device-row-${did} .used-traffic`); if(cell) cell.textContent = formatBytesJS(usage); }); }
            if(path === '#/logs') { const v = gid('log-viewer'); if(v) { v.innerHTML = appState.logs.join('\\n'); v.scrollTop = v.scrollHeight; } }
        }
        async function toggleDeviceAuth() {
            const toggle = gid('device-auth-toggle');
            const statusText = gid('device-auth-status-text');
            const isEnabled = toggle.checked;
            const originalText = statusText.textContent;
            statusText.textContent = "正在保存...";
            toggle.disabled = true;
            const r = await post("/api/settings/toggle_device_auth", { enable: isEnabled });
            if (r && r.status === 'ok') {
                alert(r.message);
                appState.settings.enable_device_id_auth = isEnabled;
                statusText.textContent = isEnabled ? "Device ID 验证: 开启" : "已关闭 (全部放行)";
            } else {
                alert(r ? r.message : "操作失败");
                toggle.checked = !isEnabled;
                statusText.textContent = originalText;
            }
            toggle.disabled = false;
        }
        async function addID() { const d = { device_id: gid("device_id").value.trim(), expiry: gid("expiry").value.trim(), limit_gb: gid("limit_gb").value.trim() || 0 }; if (!d.device_id || !d.expiry) return alert("ID和有效期不能为空"); const r = await post("/device/add", d); if (r && r.status === 'ok') { alert(r.message); const [devs, usage] = await Promise.all([get('/api/devices'), get('/api/device_usage')]); appState.devices = devs || appState.devices; appState.usage = usage || appState.usage; renderDevicePage(); } }
        async function deleteID() { const id = gid("device_id").value.trim(); if (!id) return alert("ID不能为空"); if (confirm(`确定删除?`)) { const r = await post("/device/delete", { device_id: id }); if (r && r.status === "ok") { alert(r.message); const [devs, usage] = await Promise.all([get('/api/devices'), get('/api/device_usage')]); appState.devices = devs || appState.devices; appState.usage = usage || appState.usage; gid("device_id").value = ""; gid("expiry").value = ""; gid("limit_gb").value = ""; renderDevicePage(); } } }
        async function resetTraffic() { const id = gid("device_id").value.trim(); if (!id) return alert("ID不能为空"); if (confirm(`确定重置流量?`)) { const r = await post("/device/reset_traffic", { device_id: id }); if (r && r.status === "ok") { alert(r.message); const usage = await get('/api/device_usage'); appState.usage = usage || appState.usage; renderDevicePage(); } } }
        function fillExisting() { const s = gid("existing_user"), [id, exp, lim] = s.value.split('|'); if (id) { gid("device_id").value = id; gid("expiry").value = exp; gid("limit_gb").value = lim; } }
        async function updateAccount() { const d = { old_user: gid("old_user").value, old_pass: gid("old_pass").value, new_user: gid("new_user").value, new_pass: gid("new_pass").value }; if (Object.values(d).some(v => !v)) return alert("请完整填写"); const r = await post("/account/update", d); if (r) alert(r.message); }
        async function manageSshUser(action) { const user = gid('ssh_user').value.trim(); const pass = gid('ssh_pass').value.trim(); if (!user) return alert('SSH用户名不能为空'); if (action === 'create' && !pass) return alert('创建用户时密码不能为空'); const confirmText = action === 'create' ? `确定要创建或更新SSH用户 "${user}" 吗？\\n这将修改系统用户和 sshd_config。` : `确定要删除SSH用户 "${user}" 吗？\\n这将从系统中移除用户并清理 sshd_config。`; if (!confirm(confirmText)) return; const r = await post(`/api/ssh/${action}`, { username: user, password: pass }); if (r) { alert(r.message); if (r.status === 'ok') gid('ssh_pass').value = ''; } }
        function logout() { fetch("/logout", { method: 'POST' }).finally(() => location.reload()); }
        async function kickUser(connKey, deviceId) {
            const displayName = deviceId || "此连接";
            if (confirm(`确定要踢掉连接 ${displayName} (Key: ${connKey.slice(0,16)}...) 吗?`)) { 
                const r = await post("/api/kick", { conn_key: connKey }); 
                if (r) alert(r.message); 
            }
        }
        async function clearConnection(key) { if (!key) return; await post("/api/clear", { conn_key: key }); }
        function filterTable() { const q = (gid("search_input")?.value || "").toLowerCase(); gid("connections-body")?.querySelectorAll("tr").forEach(r => { r.style.display = r.textContent.toLowerCase().includes(q) ? "" : "none"; }); }
        async function saveSettings() { const d = {}; document.querySelectorAll('[id^="s_"]').forEach(el => { d[el.id.substring(2)] = (el.type === 'checkbox') ? el.checked : el.value; }); if (confirm("确定保存并重启？\\n如果修改了管理端口, 您需要手动访问新端口。")) { const r = await post("/settings/save", d); if(r) alert(r.message); } }
        function autoFill() { const d = parseInt(gid('auto_expiry').value), t = new Date(); t.setDate(t.getDate() + d); gid('expiry').value = `${t.getFullYear()}-${('0' + (t.getMonth() + 1)).slice(-2)}-${('0' + t.getDate()).slice(-2)}`; gid('limit_gb').value = gid('auto_limit').value; }
        const routes = { '#/status': renderStatusPage, '#/device': renderDevicePage, '#/account': renderAccountPage, '#/settings': renderSettingsPage, '#/logs': renderLogsPage };
        function router() {
            activeIntervals.forEach(clearInterval); activeIntervals = [];
            const path = window.location.hash || '#/status';
            const renderFunc = routes[path] || routes['#/status'];
            document.querySelectorAll('.navbar a').forEach(a => { a.classList.toggle('active', a.getAttribute('href') === path); });
            renderFunc();
        }
        async function initializeApp() {
            contentArea.innerHTML = `<div class="card">正在初始化应用...</div>`;
            const [devices, usage, settings] = await Promise.all([get('/api/devices'), get('/api/device_usage'), get('/api/settings')]);
            appState.devices = devices || {}; appState.usage = usage || {}; appState.settings = settings;
            setInterval(updateDynamicData, 3000);
            if (!window.location.hash) { window.location.hash = '#/status'; }
            router();
        }
        window.addEventListener('hashchange', router);
        document.addEventListener('DOMContentLoaded', initializeApp);
        </script></body></html>'''
        
        html_shell = html_template.replace('__USER__', user).replace('__ACTIVE_COUNT__', str(active_count)).replace('__GLOBAL_SENT__', format_bytes(GLOBAL_BYTES_SENT)).replace('__GLOBAL_RECEIVED__', format_bytes(GLOBAL_BYTES_RECEIVED)).replace('__UPTIME__', uptime_str).replace('__CPU__', cpu_str).replace('__CPU_CORES__', cpu_cores_str).replace('__MEM__', mem_str)
        resp_bytes = html_shell.encode()
        writer.write(f"HTTP/1.1 200 OK\r\nContent-Type: text/html;charset=utf-8\r\nContent-Length: {len(resp_bytes)}\r\n\r\n".encode() + resp_bytes)
        await writer.drain()
    
    except asyncio.TimeoutError:
        print("[!] Admin interface request timed out.")
    except Exception as e:
        print(f"[!] admin_interface error: {type(e).__name__} - {e}")
    finally:
        try:
            if not writer.is_closing(): writer.close(); await writer.wait_closed()
        except: pass
