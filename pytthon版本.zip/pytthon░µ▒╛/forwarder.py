# forwarder.py
# -*- coding: utf-8 -*-

import asyncio
import re
import socket
import time
import datetime
import os
import sys

# 从共享模块导入所有需要的变量和函数
from shared_state import (
    ACTIVE_CONNS, DEVICE_USAGE, SETTINGS, CONFIG, GLOBAL_BYTES_SENT, GLOBAL_BYTES_RECEIVED,
    print
)

# 定义响应常量
FIRST_RESPONSE = b'HTTP/1.1 200 OK\r\n\r\nOK'
SWITCH_RESPONSE = b'HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n\r\n'
FORBIDDEN_RESPONSE = b'HTTP/1.1 403 Forbidden\r\n\r\n'

def set_socket_options_from_writer(writer: asyncio.StreamWriter):
    """为给定的StreamWriter设置TCP套接字选项。"""
    sock = writer.get_extra_info('socket')
    if sock:
        try:
            sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        except OSError as e:
            print(f"[*] Could not set socket options: {e}")

async def pipe(src: asyncio.StreamReader, dst: asyncio.StreamWriter, key: str, counter: str, is_upload: bool):
    """数据管道，负责在两个流之间转发数据并统计流量。"""
    global GLOBAL_BYTES_SENT, GLOBAL_BYTES_RECEIVED
    buffer_size = SETTINGS.get("buffer_size", 8192)
    try:
        while True:
            chunk = await src.read(buffer_size)
            if not chunk:
                break
            
            chunk_len = len(chunk)
            
            if is_upload:
                GLOBAL_BYTES_SENT += chunk_len
            else:
                GLOBAL_BYTES_RECEIVED += chunk_len

            # 检查连接是否仍然存在于ACTIVE_CONNS中
            if key in ACTIVE_CONNS:
                conn_info = ACTIVE_CONNS[key]
                conn_info[counter] += chunk_len
                did = conn_info.get('device_id')
                if did and did in DEVICE_USAGE: 
                    DEVICE_USAGE[did] += chunk_len
                conn_info['last_active'] = time.time()
            
            dst.write(chunk)
            await dst.drain()
    except (ConnectionResetError, asyncio.CancelledError, BrokenPipeError):
        pass  # 正常关闭或连接重置
    except Exception as e:
        print(f"[!] Error in pipe for {key}: {type(e).__name__} - {e}")
    finally:
        try:
            if not dst.is_closing():
                dst.close()
                await dst.wait_closed()
        except Exception:
            pass

def extract_header_value(text: str, names: list) -> str:
    """从HTTP头文本中提取指定头的值。"""
    for name in names:
        m = re.search(fr'(?mi)^{re.escape(name)}:\s*(.+)$', text)
        if m:
            return m.group(1).strip()
    return ''

async def handle_client(reader: asyncio.StreamReader, writer: asyncio.StreamWriter, tls: bool = False):
    """处理新的客户端连接，包括握手、认证和启动数据转发。"""
    peer = writer.get_extra_info('peername')
    ip_str = peer[0] if peer else '未知'
    conn_key = f"{ip_str}-{time.time()}-{id(writer)}"
    pipe_tasks = []
    
    try:
        now = time.time()
        ACTIVE_CONNS[conn_key] = {
            'writer': writer, 'last_active': now, 'device_id': None, 
            'first_connection': now, 'status': '握手', 'ip': ip_str, 
            'bytes_sent': 0, 'bytes_received': 0, 'conn_key': conn_key,
            'last_speed_update_time': now, 'last_total_bytes': 0
        }
        set_socket_options_from_writer(writer)
        print(f"[+] Connection from {ip_str} {'(TLS)' if tls else ''}")

        full_request = b''
        forwarding_started = False
        headers_text = ''
        
        timeout = SETTINGS.get("timeout", 300)
        
        while not forwarding_started:
            data_chunk = await asyncio.wait_for(reader.read(8192), timeout=timeout)
            if not data_chunk:
                print(f"[-] Client {ip_str} closed connection during handshake.")
                return

            full_request += data_chunk
            
            header_end_index = full_request.find(b'\r\n\r\n')
            if header_end_index == -1:
                if len(full_request) > 16384: # 防止内存攻击
                    print(f"[!] Invalid protocol from {ip_str}, no headers found.")
                    return
                continue

            headers_raw = full_request[:header_end_index]
            rest = full_request[header_end_index + 4:]
            full_request = b'' # 一次只处理一个请求

            headers_text = headers_raw.decode(errors='ignore')
            device_id = extract_header_value(headers_text, ['x-device-id', 'device-id', 'deviceid'])

            if SETTINGS.get('enable_device_id_auth', True):
                device_info = CONFIG.get('device_ids', {}).get(device_id)
                if not device_id or not device_info:
                    print(f"[!] Auth Enabled: Invalid device ID '{device_id}' from {ip_str}. Rejecting.")
                    writer.write(FORBIDDEN_RESPONSE); await writer.drain(); return
                
                try:
                    if datetime.datetime.utcnow().date() > datetime.datetime.strptime(device_info['expiry'], '%Y-%m-%d').date():
                        print(f"[!] Auth Enabled: Device ID {device_id} has expired. Rejecting.")
                        writer.write(FORBIDDEN_RESPONSE); await writer.drain(); return
                except (ValueError, TypeError):
                    print(f"[!] Auth Enabled: Invalid expiry date format for {device_id}. Rejecting.")
                    writer.write(FORBIDDEN_RESPONSE); await writer.drain(); return
                
                limit_gb = device_info.get('limit_gb', 0)
                if limit_gb > 0 and DEVICE_USAGE.get(device_id, 0) >= limit_gb * 1024**3:
                    print(f"[!] Auth Enabled: Traffic limit reached for {device_id}. Rejecting.")
                    writer.write(FORBIDDEN_RESPONSE); await writer.drain(); return

            ua_value = extract_header_value(headers_text, ['User-Agent'])
            final_device_id = device_id or "unknown_device"
            
            ACTIVE_CONNS[conn_key]['device_id'] = final_device_id

            ua_probe = SETTINGS.get("ua_keyword_probe", "1.0")
            ua_ws = SETTINGS.get("ua_keyword_ws", "26.4.0")

            if ua_probe and ua_probe in ua_value:
                print(f"[*] Received probe from {ip_str} for device '{final_device_id}'. Awaiting WS handshake.")
                writer.write(FIRST_RESPONSE); await writer.drain()
                full_request = rest # 为循环中的下一个请求准备缓冲区
                continue

            elif ua_ws and ua_ws in ua_value:
                print(f"[*] Received WebSocket handshake from {ip_str} for device '{final_device_id}'.")
                
                if not SETTINGS.get("allow_simultaneous_connections", False) and final_device_id != "unknown_device":
                    existing_conn = next((item for item in ACTIVE_CONNS.values() if item.get('device_id') == final_device_id and item['conn_key'] != conn_key), None)
                    if existing_conn:
                        print(f"[!] WS Check: Simultaneous connection rejected for device {final_device_id}. Blocked by: {existing_conn['conn_key']}")
                        writer.write(FORBIDDEN_RESPONSE); await writer.drain(); return

                ACTIVE_CONNS[conn_key]['status'] = '活跃'
                writer.write(SWITCH_RESPONSE); await writer.drain()
                forwarding_started = True # 结束握手循环
            
            else:
                print(f"[!] Unrecognized User-Agent from {ip_str}: '{ua_value}'. Rejecting.")
                writer.write(FORBIDDEN_RESPONSE); await writer.drain(); return
        
        if not forwarding_started: return

        host_header = extract_header_value(headers_text, ['x-real-host'])
        target_host = SETTINGS.get("default_target_host", "127.0.0.1")
        target_port = SETTINGS.get("default_target_port", 22)
        target = (target_host, target_port)

        if host_header:
            try:
                host, port_str = host_header.split(':', 1) if ':' in host_header else (host_header, target_port)
                target = (host.strip(), int(port_str))
            except ValueError:
                print(f"[!] Invalid Host header format: '{host_header}'")
                return

        print(f"[*] Tunneling {ip_str} -> {target[0]}:{target[1]}")
        tr, tw = await asyncio.open_connection(*target)
        
        if rest: tw.write(rest); await tw.drain()
        
        pipe_tasks = [
            asyncio.create_task(pipe(reader, tw, conn_key, 'bytes_sent', True)),
            asyncio.create_task(pipe(tr, writer, conn_key, 'bytes_received', False))
        ]
        await asyncio.wait(pipe_tasks, return_when=asyncio.FIRST_COMPLETED)

    except (ValueError, asyncio.TimeoutError) as e:
        print(f"[-] Handshake failed for {ip_str}: {e}")
    except Exception as e:
        if not isinstance(e, (asyncio.IncompleteReadError, ConnectionResetError, BrokenPipeError)):
            print(f"[!] Unhandled error in handle_client for {ip_str}: {type(e).__name__} - {e}")
    finally:
        if conn_key in ACTIVE_CONNS:
            ACTIVE_CONNS.pop(conn_key, None)
        for t in pipe_tasks:
            if not t.done(): t.cancel()
        try:
            if not writer.is_closing(): writer.close(); await writer.wait_closed()
        except Exception: pass
        print(f"[-] Closed connection for {ip_str}")
